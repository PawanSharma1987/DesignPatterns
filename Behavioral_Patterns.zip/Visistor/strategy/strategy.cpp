// strategy.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class stretgy
{
public:
	void virtual algo() = 0;
};

class stretgyA : public stretgy
{
public:
	void algo()
	{
		cout << "Inside stretgyA" << endl;
	}

};

class stretgyB : public stretgy
{
public:
	void algo()
	{
		cout << "Inside stretgyB" << endl;
	}

};

class client
{
	//has-a RelartionShip composition
	stretgy *stretgy_ = nullptr;
public:
	
	void setStretgy(stretgy *stretgyIn)
	{
		stretgy_ = stretgyIn;
	}

	void callAlgo()
	{
		stretgy_->algo();
	}

};
int main()
{
	client *context = new client();

	stretgy *st = new stretgyA();
	context->setStretgy(st);
	context->callAlgo();

	delete st;
	st = new stretgyB();
	context->setStretgy(st);
	context->callAlgo();

	delete st;
	delete context;

    return 0;
}

