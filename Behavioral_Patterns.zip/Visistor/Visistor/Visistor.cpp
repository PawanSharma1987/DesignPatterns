// Visistor.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


//int main()
//{
//    return 0;
//}
#include <iostream>
#include <string>
using namespace std;

// 1. Add an accept(Visitor) method to the "element" hierarchy
class Element
{
public:
	virtual void accept(class Visitor &v) = 0;
};

class This : public Element
{
public:
	/*virtual*/void accept(Visitor &v);
	string thiss()
	{
		return "cat sound.";
	}
};

class That : public Element
{
public:
	/*virtual*/void accept(Visitor &v);
	string that()
	{
		return "dog sound.";
	}
};

class TheOther : public Element
{
public:
	/*virtual*/void accept(Visitor &v);
	string theOther()
	{
		return "talking to each other.";
	}
};

// 2. Create a "visitor" base class w/ a visit() method for every "element" type
class Visitor
{
public:
	virtual void visit(This *e) = 0;
	virtual void visit(That *e) = 0;
	virtual void visit(TheOther *e) = 0;
};

/*virtual*/void This::accept(Visitor &v)
{
	v.visit(this);
}

/*virtual*/void That::accept(Visitor &v)
{
	v.visit(this);
}

/*virtual*/void TheOther::accept(Visitor &v)
{
	v.visit(this);
}

// 3. Create a "visitor" derived class for each "operation" to do on "elements"
class UpVisitor : public Visitor
{
	/*virtual*/void visit(This *e)
	{
		cout << "do Up on " + e->thiss() << '\n';
	}
	/*virtual*/void visit(That *e)
	{
		cout << "do Up on " + e->that() << '\n';
	}
	/*virtual*/void visit(TheOther *e)
	{
		cout << "do Up on " + e->theOther() << '\n';
	}
};

class DownVisitor : public Visitor
{
	/*virtual*/void visit(This *e)
	{
		cout << "do Down on " + e->thiss() << '\n';
	}
	/*virtual*/void visit(That *e)
	{
		cout << "do Down on " + e->that() << '\n';
	}
	/*virtual*/void visit(TheOther *e)
	{
		cout << "do Down on " + e->theOther() << '\n';
	}
};
class cat;
class dog;
class VisitorA
{
public:
	virtual void visit(dog * icat) = 0;
	virtual void visit(cat * icat) = 0;
};


class animal
{
public:
	virtual void accept(VisitorA& v) = 0;	
};

class cat : public animal
{
public :
	void accept(VisitorA& v)
	{
		v.visit(this);
	}

	void sound()
	{
		cout << "meaun meaun" << endl;
	}
};

class dog :public animal
{
public:
	void accept(VisitorA& v)
	{
		v.visit(this);
	}
	void sound()
	{
		cout << "bau bau" << endl;
	}
};

class talkVisitor :public VisitorA
{
	void visit(dog *e)
	{
		cout << "dog is talking to cat " << endl;
		e->sound() ;
	}
	void visit(cat  *e)
	{
		cout << "cat is taking to dog " << endl;
		e->sound();
	}
};
int main()
{

	animal *list[] =
	{
		new cat(), new dog()
	};

	talkVisitor talk;
	for (int i = 0; i < 2; i++)
		list[i]->accept(talk);

	//Element *list[] =
	//{
	//	new This(), new That(), new TheOther()
	//};
	//UpVisitor up; // 4. Client creates
	//DownVisitor down; //    "visitor" objects
	//for (int i = 0; i < 3; i++)
	//	//    and passes each
	//	list[i]->accept(up);
	////    to accept() calls
	//for (int i = 0; i < 3; i++)
	//	list[i]->accept(down);

	cin.get();
}
