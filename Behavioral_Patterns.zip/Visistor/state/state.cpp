// state.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
using namespace std;

// Clent Which have states and these states. when satte changes it will change the behaviour of object.
// bydefault machine gate is closed and it will open on based on some condition.

class MachineGate
{
	class State *current;//State calss
public:
	MachineGate();
	void setCurrent(State *s)
	{
		current = s;
	}
	void on();
	void off();
};

// defines the state of Machine. Once state changes it will alter the MachineGate Behaviour.
class State
{
public:
	virtual void OpenState(MachineGate *m)
	{
		cout << "   already ON\n";
	}
	virtual void closeState(MachineGate *m)
	{
		cout << "   already OFF\n";
	}
};

void MachineGate::on()
{
	current->OpenState(this);
}

void MachineGate::off()
{
	current->closeState(this);
}

// can say concrete state which will alter the behavious based on input state
class Open : public State
{
public:
	Open()
	{
		cout << "   ON-ctor ";
	};
	~Open()
	{
		cout << "   dtor-ON\n";
	};
	void closeState(MachineGate *m);
};

// can say concrete state which will alter the behavious based on input state
class close : public State
{
public:
	close()
	{
		cout << "   close-ctor ";
	};
	~close()
	{
		cout << "   dtor-close\n";
	};
	void OpenState(MachineGate *m)
	{
		cout << "   going from close to Open";
		m->setCurrent(new Open());
		delete this;
	}
};

void Open::closeState(MachineGate *m)
{
	cout << "   going from Open to close";
	m->setCurrent(new close());
	// change of state can put more checks for this state change currently kept easy to understand.
	delete this;
}

MachineGate::MachineGate()
{
	current = new close();// default state
	cout << '\n';
}

int main()
{
	// arrray of funtion pointers to memeber functions.
	void(MachineGate:: *ptrs[])() =
	{
		&MachineGate::off, &MachineGate::on
	};
	MachineGate obj;
	int num;
	while (1)
	{
		cout << "Enter 0/1: ";
		cin >> num;
		(obj.*ptrs[num])();
	}
}

