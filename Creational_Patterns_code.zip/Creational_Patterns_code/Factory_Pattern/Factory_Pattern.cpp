// Factory_Pattern.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
using namespace std;

#include "ToyFactory.h"

int main() {
	// client code starts
	int type;
	while (1) {
		cout << endl << "Enter type or Zero for exit" << endl;
		cin >> type;
		if (!type)
			break;
		Toy *v = ToyFactory::createToy(type);
		if (v) {
			v->showProduct();
			delete v;
		}
	}
	cout << "Exit.." << endl;
	// client code ends
	return 0;
}

