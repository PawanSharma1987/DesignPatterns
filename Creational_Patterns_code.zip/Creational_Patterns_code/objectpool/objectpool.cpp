// objectpool.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <vector>
#include <mutex>

using namespace std;

class Resource
{
	int value = 0;
public:
	Resource()
	{
		value = 0;
	}
	void reset()
	{
		value = 0;
	}
	int getValue()
	{
		return value;
	}
	void setValue(int number)
	{
		value = number;
	}
};



class Pool
{
protected:
	std::vector<Resource*> resources;
	
public:
	virtual Resource* getResource() = 0;
	virtual void returnResource(Resource* object) = 0;
	
};

std::mutex g_mutex;
class FixedResoursePool : public Pool
{
	static  Pool* poolObj;
	 
	FixedResoursePool() = default;
	FixedResoursePool(const FixedResoursePool&) = default;
	FixedResoursePool & operator =(const FixedResoursePool&) = default;
public:
	
	static Pool *getPoolInstance()
	{
		if (poolObj == nullptr)
		{
			std::lock_guard<std::mutex> lock(g_mutex);
			if (poolObj == nullptr)
			{
				poolObj = new FixedResoursePool();
			}
		}
	
		return poolObj;
	}
	Resource* getResource()
	{
		if (resources.empty())
		{
			std::cout << "Creating new." << std::endl;
			return new Resource;
		}
		else
		{
			std::cout << "Reusing existing." << std::endl;
			Resource* resource = resources.back();
			resources.pop_back();
			return resource;
		}
	}

	void returnResource(Resource* object)
	{
		object->reset();
		resources.push_back(object);
	}
};

Pool* FixedResoursePool::poolObj = nullptr;

class DynamicResoursePool : public Pool
{
public:
	Resource* getResource()
	{
		if (resources.empty())
		{
			std::cout << "Creating new." << std::endl;
			return new Resource;
		}
		else
		{
			std::cout << "Reusing existing." << std::endl;
			Resource* resource = resources.back();
			resources.pop_back();
			return resource;
		}
	}

	void returnResource(Resource* object)
	{
		object->reset();
		resources.push_back(object);
	}
};


class PoolFactory
{	
	static Pool *resource ;
public:
	static Pool *getInstance(int type)
	{
		switch (type)
		{
		case 1:
			 resource = FixedResoursePool::getPoolInstance();
			 break;
		case 2:
			resource = new DynamicResoursePool();
			break;
		default:
			cout << "WrongInput" << endl;

		}

		return resource;
	}

};
Pool *PoolFactory::resource =nullptr;
int main()
{

	Resource* one;
	Resource* two;
	int val;
	cout << "Enter 1 for Proceed." << endl;
	cin >> val;
	auto poolresource = PoolFactory::getInstance(val);
	one = poolresource->getResource();
	one->setValue(10);
	std::cout << "one = " << one->getValue() << " [" << one << "]" << std::endl;
	two = poolresource->getResource();
	two->setValue(20);
	std::cout << "two = " << two->getValue() << " [" << two << "]" << std::endl;
	poolresource->returnResource(one);
	poolresource->returnResource(two);

	one = poolresource->getResource();
	std::cout << "one = " << one->getValue() << " [" << one << "]" << std::endl;
	two = poolresource->getResource();
	std::cout << "two = " << two->getValue() << " [" << two << "]" << std::endl;

	cin.get();

	return 0;
}

