//// abstractFactory.cpp : Defines the entry point for the console application.
//// Creates the Realted objects 
////  
//
//#include "stdafx.h"
//#include <iostream>
//
//using namespace std;
//
//class Shape {
//public:
//	Shape() {
//		id_ = total_++;
//	}
//	virtual void draw() = 0;
//protected:
//	int id_;
//	static int total_;
//};
//int Shape::total_ = 0;
//
//class Circle : public Shape {
//public:
//	void draw() {
//		cout << "circle " << id_ << ": draw" << endl;
//	}
//};
//class Square : public Shape {
//public:
//	void draw() {
//		cout << "square " << id_ << ": draw" << endl;
//	}
//};
//class Ellipse : public Shape {
//public:
//	void draw() {
//		cout << "ellipse " << id_ << ": draw" << endl;
//	}
//};
//class Rectangle : public Shape {
//public:
//	void draw() {
//		cout << "rectangle " << id_ << ": draw" << endl;
//	}
//};
//
//class Factory {
//public:
//	virtual Shape* createCurvedInstance() = 0;
//	virtual Shape* createStraightInstance() = 0;
//};
//
//class SimpleShapeFactory : public Factory {
//public:
//	Shape* createCurvedInstance() {
//		return new Circle;
//	}
//	Shape* createStraightInstance() {
//		return new Square;
//	}
//};
//class RobustShapeFactory : public Factory {
//public:
//	Shape* createCurvedInstance() {
//		return new Ellipse;
//	}
//	Shape* createStraightInstance() {
//		return new Rectangle;
//	}
//};
//#define SIMPLE
//int main() {
//#ifdef SIMPLE
//	Factory* factory = new SimpleShapeFactory;
//#elif ROBUST
//	Factory* factory = new RobustShapeFactory;
//#endif
//	Shape* shapes[3];
//
//	shapes[0] = factory->createCurvedInstance();   // shapes[0] = new Ellipse;
//	shapes[1] = factory->createStraightInstance(); // shapes[1] = new Rectangle;
//	shapes[2] = factory->createCurvedInstance();   // shapes[2] = new Ellipse;
//
//	for (int i = 0; i < 3; i++) {
//		shapes[i]->draw();
//	}
//}

// builder.cpp : Defines the exported functions for the DLL application.
// Creation of complex objects step by step

#include "stdafx.h"
#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;


enum PersistenceType
{
	File, Queue, Pathway
};

struct PersistenceAttribute
{
	PersistenceType type;
	char value[30];
};

class DistrWorkPackage
{
public:
	DistrWorkPackage(char *type)
	{
		sprintf_s(_desc, "Distributed Work Package for: %s", type);
	}
	void setFile(char *f, char *v)
	{
		sprintf_s(_temp, "\n  File(%s): %s", f, v);
		strcat_s(_desc, _temp);
	}
	void setQueue(char *q, char *v)
	{
		sprintf_s(_temp, "\n  Queue(%s): %s", q, v);
		strcat_s(_desc, _temp);
	}
	void setPathway(char *p, char *v)
	{
		sprintf_s(_temp, "\n  Pathway(%s): %s", p, v);
		strcat_s(_desc, _temp);
	}
	const char *getState()
	{
		return _desc;
	}
private:
	char _desc[200], _temp[80];
};

class Builder
{
public:
	virtual void configureFile(char*) = 0;
	virtual void configureQueue(char*) = 0;
	virtual void configurePathway(char*) = 0;
	DistrWorkPackage *getResult()
	{
		return _result;
	}
protected:
	DistrWorkPackage *_result;
};

class UnixBuilder : public Builder
{
public:
	UnixBuilder()
	{
		_result = new DistrWorkPackage("Unix");
	}
	void configureFile(char *name)
	{
		_result->setFile("flatFile", name);
	}
	void configureQueue(char *queue)
	{
		_result->setQueue("FIFO", queue);
	}
	void configurePathway(char *type)
	{
		_result->setPathway("thread", type);
	}
};

class VmsBuilder : public Builder
{
public:
	VmsBuilder()
	{
		_result = new DistrWorkPackage("Vms");
	}
	void configureFile(char *name)
	{
		_result->setFile("ISAM", name);
	}
	void configureQueue(char *queue)
	{
		_result->setQueue("priority", queue);
	}
	void configurePathway(char *type)
	{
		_result->setPathway("LWP", type);
	}
};

class Reader
{
public:
	void setBuilder(Builder *b)
	{
		_builder = b;
	}
	void construct(PersistenceAttribute[], int);
private:
	Builder *_builder;
};

void Reader::construct(PersistenceAttribute list[], int num)
{
	for (int i = 0; i < num; i++)
		if (list[i].type == File)
			_builder->configureFile(list[i].value);
		else if (list[i].type == Queue)
			_builder->configureQueue(list[i].value);
		else if (list[i].type == Pathway)
			_builder->configurePathway(list[i].value);
}

const int NUM_ENTRIES = 6;
PersistenceAttribute input[NUM_ENTRIES] =
{
	{
		File, "state.dat"
	}
	,
	{
		File, "config.sys"
	}
	,
	{
		Queue, "compute"
	}
	,
	{
		Queue, "log"
	}
	,
	{
		Pathway, "authentication"
	}
	,
	{
		Pathway, "error processing"
	}
};

int main()
{
	UnixBuilder unixBuilder;
	VmsBuilder vmsBuilder;
	Reader reader;

	reader.setBuilder(&unixBuilder);
	reader.construct(input, NUM_ENTRIES);
	cout << unixBuilder.getResult()->getState() << endl;

	reader.setBuilder(&vmsBuilder);
	reader.construct(input, NUM_ENTRIES);
	cout << vmsBuilder.getResult()->getState() << endl;
}